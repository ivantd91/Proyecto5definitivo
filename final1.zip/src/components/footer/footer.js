import './footer.css'
export function footer() {
  const footer = document.querySelector('app')
  const footerSeccion = document.createElement('section')
  footerSeccion.id = 'footer'
}
