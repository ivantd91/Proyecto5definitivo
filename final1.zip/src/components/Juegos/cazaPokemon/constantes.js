export const maxVivos = 8
export const spawnIntervaloPokemon = 500
export const ICONOS = [
  pikachuImg,
  caterpieImg,
  squirtleImg,
  rattataImg,
  snorlaxImg
]
