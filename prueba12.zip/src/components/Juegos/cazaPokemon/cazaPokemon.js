import './cazaPokemon.css'

import { iniciarJuegoCazaPokemon } from './logicaJuegoPokemon.js'

export function juegoCazaPokemon() {
  return iniciarJuegoCazaPokemon()
}
