import './tresEnRaya.css'
import { mostrarVentanaGanadora } from '../../componentesVisuales/modalGanador.js'

export function juegoTresEnRaya() {
  let tablero = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
  ]
  let turno = 'X'

  divPrincipalTresEnRaya = document.createElement('div')
  divPrincipalTresEnRaya.className = 'divTresEnRaya'

  const info = document.createElement('div')
  info.className = 'infoTresEnRaya'
  info.textContent = `turno: ${turno}`
  divPrincipalTresEnRaya.appendChild(info)

  const grid = document.createElement('div')
  grid.className = 'tableroTresEnRaya'

  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      const celda = document.createElement('div')
      celda.className = 'celdaTresEnRaya'

      celda.addEventListener('click', () => clickCelda(i, j, celda))
      grid.appendChild(celda)
    }
  }

  divPrincipalTresEnRaya.appendChild(grid)

  return divPrincipalTresEnRaya

  function clickCelda(i, j, celdaEl) {
    if (tablero[i][j] || comprobarGanador()) return

    tablero[i][j] = turno
    celdaEl.textContent = turno
    celdaEl.classList.add(turno === 'X' ? 'celdaX' : 'celda0')

    if (comprobarGanador()) {
      mostrarVentanaGanadora(() => {
        const nuevo = juegoTresEnRaya()
        const app = document.getElementById('app')
        app.innerHTML = ''
        app.appendChild(nuevo)
      }, `${turno} ha ganado!!🎉`)
      return
    }
    if (tablero.flat().every((c) => c)) {
      mostrarVentanaGanadora(() => {
        const nuevo = juegoTresEnRaya()
        const app = document.getElementById('app')
        app.innerHTML = ''
        app.appendChild(nuevo)
      }, `${turno} Empate!!😐`)
      return
    }
    turno = turno === 'X' ? '0' : 'X'
    info.textContent = `turno: ${turno}`
  }

  function comprobarGanador() {
    const lineas = [
      [
        [0, 0],
        [0, 1],
        [0, 2]
      ],
      [
        [1, 0],
        [1, 1],
        [1, 2]
      ],
      [
        [2, 0],
        [2, 1],
        [2, 2]
      ],

      [
        [0, 0],
        [1, 0],
        [2, 0]
      ],
      [
        [0, 1],
        [1, 1],
        [2, 1]
      ],
      [
        [0, 2],
        [1, 2],
        [2, 2]
      ],

      [
        [0, 0],
        [1, 1],
        [2, 2]
      ],
      [
        [0, 2],
        [1, 1],
        [2, 0]
      ]
    ]
    return lineas.some((linea) => {
      const [a, b, c] = linea
      return (
        tablero[a[0]][a[1]] &&
        tablero[a[0]][a[1]] === tablero[b[0]][b[1]] &&
        tablero[a[0]][a[1]] === tablero[c[0]][c[1]]
      )
    })
  }
}
