export const estadoCazaPokemon = {
  intervalo: null
}
